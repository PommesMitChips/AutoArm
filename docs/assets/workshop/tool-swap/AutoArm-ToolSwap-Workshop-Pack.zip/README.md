# ToolSwap Workshop assets

Open `preview.html` to view the setup panels.

- `panels/`: ToolSwap setup instructions as transparent PNGs.
- `branding/`: AutoArm and ToolSwap titles and thumbnails.
- `autoarm-pairing.ini`: Example AutoArm Custom Data settings.
- `toolswap-pairing.ini`: Example ToolSwap Custom Data settings.

Use the PNGs in a Workshop description or another guide. For pairing, copy the
settings into the matching arm sections of the programmable blocks' Custom Data,
and replace the example arm and PB names with your own.

Use the SVG panel library in the AutoArm repo to edit the panel text and artwork.
