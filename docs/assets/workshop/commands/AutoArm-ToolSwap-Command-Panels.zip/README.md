# AutoArm and ToolSwap commands

Open `preview.html` to browse the command panels.

- `panels/`: PNGs for a Workshop description or guide.
- `commands.txt`: Command names, arguments and examples to copy.
- `catalog.json`: Panel text organised by command.

The images have transparent backgrounds and light text for dark pages.
Use the SVG panel library in the AutoArm repo to edit the artwork or text.
