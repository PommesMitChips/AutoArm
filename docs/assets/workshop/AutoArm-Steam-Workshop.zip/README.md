# AutoArm Workshop guide

Open `preview.html` to view the guide.

## Add it to your Workshop page

1. Upload the images in `png/` to an image host.
2. Copy the direct image URLs.
3. Replace the image placeholders in `getting-started.bbcode.txt` with those URLs.
   `manifest.json` lists the corresponding filenames.
4. Paste the completed BBCode into your Workshop description.

The PNGs have transparent backgrounds and light text for dark pages.
