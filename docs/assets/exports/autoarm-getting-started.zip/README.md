# AutoArm

AutoArm is a mechanical-arm control program for the Space Engineers programmable block. It simplifies setup of robotic arms to configuring the start and endpoint of an arm, while allowing later fine tuning of parameters via CustomData within the programmable block.

New to AutoArm? Follow the [illustrated Getting Started guide](docs/GETTING_STARTED.md).

## Installation

1. Stop your existing arm controller before replacing it.
2. Paste the entire [Arm script](https://github.com/PommesMitChips/AutoArm/blob/v5.1.0/AutoArm_Compact.txt) into an arm programmable block.
3. For tool parking/swapping, paste the [ToolSwap script](https://github.com/PommesMitChips/AutoArm/blob/v5.0.1/AutoArm_ToolSwap_Compact.txt) into a second PB on the same construct. Keep both PBs running. Their names do not matter for automatic setup.
4. Name the parts as shown below. You do not need to edit the code or enter configuration for a quick start.
5. Run `On` on the Arm PB. For another arm, use `On(Arm 2)`. Then use `Select Arm 2` to give it cockpit control.

Keep existing Custom Data when its format matches: Arm PBs use `[global] Format=7`; ToolSwap PBs use `[global] Format=2`. If a format error asks you to delete old data, let this version generate the new layout. Incorrect formats are not converted.

## Choose a setup

### Simple arm

Name the first attached joint **`Arm 1 - Base - Rotor`** (or `Arm 1 - Base - Piston` / `Arm 1 - Base - Hinge`). Name exactly one terminal block on the moving end **`Arm 1 - Head - Drill`**, or another description after `Head -`.

Intermediate pistons, rotors and hinges do not need special names. Use only the Arm PB. Run `On` and pilot from your active cockpit.

For a parallel base, name only one member `Arm 1 - Base`. Parallel hinges/rotors must share the same rotation axis; opposite-facing members are supported. Parallel pistons may be offset from one another. Partners can share a top grid or follow matching branches that join farther up the arm. Branches must have equal stage counts and compatible joints. The arm limit is 48 physical actuators in 24 stages, including the base partners.

### Optional collision avoidance

Install the [Collision script](https://github.com/PommesMitChips/AutoArm/blob/v5.0.5/AutoArm_Collision_Compact.txt) in another PB on the same construct and name it **`Collision PB`**. Add this key to the Arm PB's existing `[global]` section, retaining any other peer rows:

```ini
Peers=
|Collision PB | Safety
```

Run `On` on the Arm PB. Collision PB generates its own settings and scans the ship and arm grids automatically. One Collision PB can supervise several arms across several Arm PBs; add the same peer entry to each owner. To supervise only one arm, put `Peers` in that arm's section instead of `[global]`.

AutoArm uses spare joint movement to improve clearance while tracking the head. When necessary it limits motion toward obstacles or holds. Moving away remains allowed. An enabled Safety service must remain running; lost or stale guidance holds the arm until fresh guidance returns. Basic arms need no Collision PB and no Safety peer entry.

Collision PB commands are `Info`, `Rescan`, `On`, `Reload` and `Off`. Run `Rescan` after adding or removing ship blocks. Adjust `Clearance`, `Influence` and `AwaySpeed` in its Custom Data, then `Reload`. If `Info` reports a scan limit, increase `MaxCells` or `MaxShapes` within the accepted range.

For a repeatable two-arm test, first collect a read-only geometry report with [Arm Survey](docs/IN_GAME_SURVEY.md). It records starting head poses without commanding movement; use that report to prepare the head paths before testing through ArmService with Safety enabled.

The [two-arm test runner](docs/IN_GAME_BENCH.md) provides a readiness check, small outward-and-return tests, simultaneous head crossing and sweeps past the opposite arm's base. `Rebase` records a new test start from both idle arms without commanding movement. Preview commands show the requested paths before movement. It requires live Safety permission and operates through ArmService; inability to pass safely stops the test.

An optional [self-collision filter prototype](docs/SELF_PAIR_PROTOTYPE.md) can report which segment pairs can safely be excluded from repeated checking. It starts in Shadow mode, retaining the normal checks; the guide explains how to test enabled exclusions and revert.

This first version uses conservative occupied-block volumes, rather than exact model shapes. Intended joint and docking contacts have limited allowances. It covers construct geometry and registered arms; terrain, unrelated ships and automatic routes around traps are not covered. Clearance checks do not model every SE physics effect, so begin with low movement speeds and confirm clearance on your build.

### Tool parking and swapping

Start with the tools securely merged to their stands. Each tool carries a rotor **base**; the compatible unnamed rotor **top** stays on the arm. Place one or more tool-side merge blocks facing matching stand merges.

If you manually detach a known tool while using the arm, or after a failed swap, AutoArm can rediscover the bare tip and return to cockpit control. It cancels the old swap first. A damaged arm or pending attachment stays stopped; explicit `Stop`, `Off` or `SwapCancel` also prevents automatic recovery.

Name only the arm base and **one reference block per tool**:

| Part | Example name |
| --- | --- |
| First arm joint | `Arm 1 - Base - Rotor` |
| Drill head reference | `Arm 1 - Head 1 - Drill` |
| Welder head reference | `Arm 1 - Head 2 - Welder` |

Leave the rotor bases, rotor top and merge blocks with their ordinary names. Do not give several blocks the same `Head 1` or `Head 2` marker pattern. A reference block can be a drill, welder, grinder or another terminal block rigidly connected to that tool.

Install both scripts and run `On` on the Arm PB. AutoArm finds the tools, rotor bases and facing merge pairs, then saves the setup in each reference block's Custom Data. That data stays with the tool across PB restarts. You do not need to mount every tool once, teach a pose, name the mounts/merges, or fill their names into PB configuration.

The bare arm needs exactly one loose compatible rotor top at its moving end. It may sit directly on the last hinge's moving head. Tool couplers use rotors; ordinary arm joints may use hinges. For first pickup, leave the tool rotor's angle limits unlimited. Rotor Lock is supported.

- `Tool 2` or `Tool Head 2` picks up Head 2, parking the current tool first.
- `Tool(2,Arm 2)` performs the same operation for Arm 2.
- `Park` returns the current tool to its stand and detaches it.
- Successful pickup/swap automatically returns the arm to ON control. Parking leaves it OFF; run `On` if you want to move the bare arm manually.

Tools approach at the arm's normal speed, align in front of the socket and enter in a straight line. Detachment backs out before travel. Start with all tools parked so their existing return orientations are preserved. Keep routes clear: AutoArm does not avoid ship geometry.

If a tool has more than one possible rotor base in its rigid region, or two reference markers describe the same tool, scanning refuses the ambiguous setup. The reference, coupler and tool merges must belong to the same connected tool body.

## Use and features

AutoArm supports mixed piston/rotor/hinge arms, offset joints, compatible parallel actuators, opposite-facing rotary pairs, position/orientation hold, saved Home positions, ordered motion paths and automatic tool parking/swapping.

Tool changes pause briefly while connections settle, then restore arm control automatically. `Tool ready; waiting for arm ON confirmation` means the handoff is pending. `Tool ready; arm ON` confirms the arm has resumed. A failed handoff reports its reason.

Pickup slows at the point in front of the mount, then continues into it. Parking enables the head merges during approach. Once they connect, the arm stops, verifies the stand connection and detaches the tool mount. Small vibration does not have to die away before the merges can connect.

### Several arms

One Arm PB can host up to eight arms within its instruction budget. Each arm has its own state, targets, joint settings, Home, tool session and faults. Different cockpits can control different arms simultaneously. Larger setups can distribute arms across more Arm PBs.

Name each arm's base and heads using its own name. While exactly one cockpit is occupied, run `Select Arm 1` to pair that seat with Arm 1. Cockpits need no special names or configuration. Pairings survive PB restarts. An arm name must belong to exactly one Arm PB; update every Arm PB to v5.1.0 when using cockpit pairing across several PBs.

For two players:

1. Only Player 1 is seated. Run `Select(HRZ, Arm 1)` to pair their cockpit and choose HRZ.
2. Player 1 briefly leaves their seat. Player 2 sits in their own cockpit and runs `Select(VRT, Arm 2)`.
3. Both players can now sit and control their paired arms independently.

If selection is attempted with multiple occupied cockpits, it fails immediately: **More than one cockpit is occupied. Please ensure exactly one cockpit is occupied.** Existing pairings and selection remain unchanged. After making exactly one seat occupied, run the selection command again.

`Release Arm 1` removes its cockpit pairing and leaves it holding. Selecting another arm from the same seat transfers that seat's control, including across Arm PBs. A missing or empty paired cockpit never falls back to another player's seat. Use `MovementMode` in each arm's Custom Data for its startup view; pairing remembers the seat, while runtime `Mode` choices reset on reload.

Commands without a target go to that PB's selected arm, which is a shared command target. In multiplayer, use explicit arm arguments for toolbar commands, including `Mode(HRZ, Arm 1)` and `Mode(VRT, Arm 2)` while both players are seated:

```text
On(Arm 2)
MoveTo(2,0,1,Arm 2)
OrientTo(1,0,0,0,0,1,Arm 2)
Tool(2,Arm 2)
Stop(Arm 2)
```

The existing toolbar style also works: `MoveTo 2 0 1, Arm 2`. `StopAll` stops every arm in that PB.

One ToolSwap PB can serve several arms, including arms hosted by different Arm PBs. Automatic linking works when each arm has one eligible partner PB. For deliberately split or ambiguous setups, list only that PB's arms in its Custom Data and set `ToolSwapPB` / `Link.ArmPB` explicitly. See [MultiArm.ini](examples/MultiArm.ini) and [MultiArmTools.ini](examples/MultiArmTools.ini).

### Movement views

| Mode | W/S | A/D | C/Space |
| --- | --- | --- | --- |
| `HEAD` | Head Forward/Back | Head Left/Right | Head Down/Up |
| `HRZ` | Cockpit Forward/Back | Cockpit Left/Right | Cockpit Down/Up |
| `VRT` | Cockpit screen Up/Down | Cockpit Left/Right | Into/out of the view |

Translation holds head orientation. Q/E rolls around the head. Optional mouse input controls pitch/yaw. AutoArm uses the arm's paired cockpit; a basic unpaired setup uses the sole active cockpit. Neither needs a special name.

Set `MovementMode=HEAD`, `HRZ` or `VRT` in Custom Data for the default. `Mode VRT` changes the selected arm's current view; `Mode(VRT,Arm 2)` targets Arm 2. Use `ReadMouse On` / `ReadMouse Off` to enable/disable mouse turning.

### Toolbar commands

Use a programmable block **Run** action with one of these arguments. The optional final arm name applies to every arm command.

| Argument | Action |
| --- | --- |
| `On` | Load settings, discover/scan and enable control |
| `Select Arm 1` / `Select(HRZ, Arm 1)` | Pair the sole occupied cockpit; optionally choose its view |
| `Release Arm 1` | Remove that arm's cockpit pairing |
| `Off` / `Stop` | Stop the target arm |
| `Hold` | Hold its current head pose |
| `Reload` / `Rescan` | Reload settings / rediscover while OFF |
| `Check` / `Info` / `Joints` | Inspect the setup |
| `SetHome` / `GoHome` | Save / return to that arm's Home |
| `MoveTo x y z` | Move while holding orientation |
| `OrientTo fx fy fz ux uy uz` | Turn while holding position |
| `MoveToPosOri x y z fx fy fz ux uy uz` | Set both |
| `Path <pose> \| <pose> ...` | Follow up to 32 poses |
| `Mode HEAD` / `Mode HRZ` / `Mode VRT` | Choose a movement view |
| `ToolScan` / `ToolInfo` | Scan / inspect tools |
| `Tool 2` / `Tool Head 2` | Select a numbered tool |
| `Park` / `SwapCancel` | Park / cancel the target arm's tool operation |

Directional actions include `Forward`, `Back`, `Left`, `Right`, `Up`, `Down`, `PitchUp`, `PitchDown`, `YawLeft`, `YawRight`, `RollLeft` and `RollRight`.

Without a tool, these actions aim the exposed rotor socket. HEAD movement follows that socket's facing direction, and Q/E rolls around it. With a tool attached, controls use the named tool reference block.

`MoveTo` positions are metres from that arm's base in its Forward, Left and Up directions. Orientation commands use those same base directions. `Path` rows use world position, forward and up: nine numbers per pose, separated by `|`. AutoArm reaches each waypoint in order and holds the final pose.

Pilot input cancels an automatic path or tool operation only for the arm receiving that input. `Stop` also cancels it; inspect the equipment, then run `On` to resume. `Reload`, `Check` and `ToolScan` remain available but are not prerequisites for `On`.

### Fine tuning

Custom Data is divided into `[global]` and one section per arm, such as `[Arm 1]` and `[Arm 2]`. Missing settings are generated automatically. Values apply in this order: built-in default, global setting, then arm override. Edit settings and run `On(Arm 2)` on the Arm PB to apply them to both scripts for Arm 2, or `Reload(Arm 2)` to remain OFF.

Use `HeadSpeed` / `HeadTurnSpeed` for movement, `JointSpeed` / `PistonSpeed` for actuator caps, and their acceleration settings to control changes in speed. ToolSwap settings use names such as `Tools.ApproachDistance`, `Tools.MoveSpeed` and `Tools.TurnSpeed`. Travel inherits arm speed; final insertion/withdrawal defaults to 0.05 m/s and 2 degrees/s.

Parking alignment defaults to `Tools.PositionTolerance=0.01` metres and `Tools.AngleTolerance=1` degree. Rotor pickup uses tighter alignment automatically. Parking confirms support before detaching; pickup confirms attachment before releasing support. Existing values in Custom Data take priority over these defaults.

`PositionDamping` and `OrientationDamping` are optional and default to `0` (off). Existing explicit values remain unchanged. Pilot input remains additive, and idle deadbands ignore small movement jitter. If the display says cockpit input is inactive, run `Select <arm name>`; `On` does not take input ownership from another selected arm.

The `Actuators` table gives stage Translation/Orientation preferences from 0 to 10. Put it under `[global]` to share it across structurally identical arms. AutoArm checks joint kinds, parallel member counts and split/rejoin layout; a nonconforming arm reports an error and stays OFF. Different lengths and mounting geometry are allowed and checked separately for each arm. Use local `Actuators` and `Structure` overrides for a different arrangement. Detachable tool couplers are excluded from the shared arm-body template.

Optional helper PBs can plan paths, observe state or stop movement. Add their exact names to `Peers` with `Plan`, `Observe` or `Stop` permissions; see [Modules.ini](examples/Modules.ini). They need a compatible script. The integration guide is [PB modules and paths](docs/MODULES.md).

## Acknowledgements

Development began with a mining-arm adaptation inspired by [Philippe117's MArmOS](https://github.com/Philippe117/MArmOS). AutoArm now uses its own automatic discovery and task-space control architecture.
